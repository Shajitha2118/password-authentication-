import tkinter as tk
from tkinter import *
from tkinter import ttk

from tkinter.filedialog import askopenfilename
from PIL import Image, ImageTk, ImageDraw

import pickle
from tkinter import messagebox
from tkinter.filedialog import askopenfilename
import random
from tkinter import filedialog

class GraphicalPasswordApp(tk.Tk):

    def __init__(self, *args, **kwargs):
        
        tk.Tk.__init__(self, *args, **kwargs)
        container = tk.Frame(self)

        container.pack(side="top", fill="both", expand = True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (StartPage, RegistrationPage, LoginPage, Page1, Page2, HomePage):

            frame = F(container, self)

            self.frames[F] = frame

            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(StartPage)

    def show_frame(self, cont):

        frame = self.frames[cont]
        frame.tkraise()

        
class StartPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)

        frame = tk.Frame(self,bg="white")
        frame.pack(fill="both",expand=True)

        label = tk.Label(frame, bg="white", text="GRAPHICAL PASSWORD AUTHENTICATION SYSTEM", font=("Arial", 30), pady=30)
        label.pack(pady=10,padx=10)

        canvas = tk.Canvas(frame, width=200, height=200)
        canvas.pack(pady=20)
        
        logo = Image.open('logo.png').resize((200, 200))

        logo = ImageTk.PhotoImage(logo)
        canvas.background = logo
        canvas.create_image(0, 0, anchor="nw", image=logo)

        button1 = tk.Button(frame, text="REGISTER NOW", width=20, height=2, bg = "firebrick", foreground = "white",
                            command=lambda: controller.show_frame(RegistrationPage))
        button1.pack(pady=20)

        button2 = tk.Button(frame, text="LOGIN", width=20, height=2, bg = "firebrick", foreground = "white",
                            command=lambda: controller.show_frame(LoginPage))
        button2.pack(pady=5)


class RegistrationPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        frame = tk.Frame(self,bg="white")
        frame.pack(fill="both",expand=True)

        button1 = tk.Button(frame, text="BACK", width=10, height=1, bg = "firebrick", foreground = "white",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack(pady=20, anchor='w', padx=10)

        label = tk.Label(frame, bg="white", text="REGISTER NEW USER HERE", font=("Arial", 30), pady=30)
        label.pack(pady=10,padx=10)

        label2 = tk.Label(frame, text = "USERNAME", bg="white")
        label2.pack()

        username = tk.Entry(frame, bd=2)
        username.pack(pady=5,ipadx=50, ipady=5)

        label3 = tk.Label(frame, text = "PASSWORD", bg="white")
        label3.pack()
        
        password = tk.Entry(frame, bd=2, show = "*")
        password.pack(pady=5,ipadx=50, ipady=5)

        label4 = tk.Label(frame, text = "CONFIRM PASSWORD", bg="white")
        label4.pack()
        
        confirmpassword = tk.Entry(frame, bd=2, show = "*")
        confirmpassword.pack(pady=5,ipadx=50, ipady=5)

        def callback():

            current_user_dict = {}
            registered_user_dict = {}
            
            registered_users = []
            
            username_data = username.get()
            username.delete(0,END)
            username.insert(0,"")
            
            password_data = password.get()
            password.delete(0,END)
            password.insert(0,"")
            
            confirmpassword_data = confirmpassword.get()
            confirmpassword.delete(0,END)
            confirmpassword.insert(0,"")
            
            try:
                pickle_in = open("usersdata.pickle", "rb")
                pickledata = pickle.load(pickle_in)
                current_user_dict = pickledata.get('current_user_dict')

                pickle_in = open("registeredusers.pickle", "rb")
                pickledata = pickle.load(pickle_in)
                registered_user_dict = pickledata.get('registered_user_dict')

                for i in registered_user_dict:
                    registered_users.append(i)
            except:
                pass

            
            if username_data == "":
                messagebox.showinfo("Alert!", "Please enter username!")

            elif password_data == "":
                messagebox.showinfo("Alert!", "Please enter password!")

            elif confirmpassword_data == "":
                messagebox.showinfo("Alert!", "Please enter confirm password!")

            else:
                if username_data not in registered_users:
                    if password_data != confirmpassword_data:
                        messagebox.showinfo("Alert!", "Please check your password!")
                    else:
                        current_user_dict["currentuser"] = {"username": username_data,
                                                               "password": password_data,
                                                               "gridimage": "NA",
                                                               "0": "NA",
                                                               "1": "NA",
                                                               "2": "NA",
                                                               "3": "NA",
                                                               "4": "NA",
                                                               "5": "NA",
                                                               "6": "NA",
                                                               "7": "NA",
                                                               "8": "NA"}

                        pickle_out = open("usersdata.pickle", "wb")
                        pickledata = {'current_user_dict': current_user_dict}
                        pickle.dump(pickledata, pickle_out)
                        pickle_out.close()

                        controller.show_frame(Page1)
                else:
                    messagebox.showinfo("Alert!", "Account with this username already exist!")
                    

        button2 = tk.Button(frame, text="SUBMIT", width=10, height=1, bg = "firebrick", foreground = "white", command=callback)
        button2.pack(pady=20, padx=10)

class LoginPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        frame = tk.Frame(self,bg="white")
        frame.pack(fill="both",expand=True)

        button1 = tk.Button(frame, text="BACK", width=10, height=1, bg = "firebrick", foreground = "white",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack(pady=20, anchor='w', padx=10)

        label = tk.Label(frame, bg="white", text="LOGIN HERE", font=("Arial", 30), pady=30)
        label.pack(pady=10,padx=10)

        label2 = tk.Label(frame, text = "USERNAME", bg="white")
        label2.pack()

        username = tk.Entry(frame, bd=2)
        username.pack(pady=5,ipadx=50, ipady=5)

        label3 = tk.Label(frame, text = "PASSWORD", bg="white")
        label3.pack()
        
        password = tk.Entry(frame, bd=2, show = "*")
        password.pack(pady=5,ipadx=50, ipady=5)

        def callback():

            current_user_dict = {}
            registered_user_dict = {}
            all_users={}
            
            registered_users = []
            
            username_data = username.get()
            username.delete(0,END)
            username.insert(0,"")
            
            password_data = password.get()
            password.delete(0,END)
            password.insert(0,"")
            
            
            try:
                pickle_in = open("allusers.pickle", "rb")
                pickledata = pickle.load(pickle_in)
                current_user_dict = pickledata.get('all_users')

            except:
                pass

            file = open('log.txt','w')
            file.write(str(pickledata))

            
            if username_data == "":
                messagebox.showinfo("Alert!", "Please enter username!")

            elif password_data == "":
                messagebox.showinfo("Alert!", "Please enter password!")

            else:
                try:
##                    print("usr"+username_data)
##                    print("current_user_dict.get"+str(current_user_dict.get(username_data)["username"]))
                    if username_data == current_user_dict.get(username_data)["username"]:
                        if password_data == current_user_dict.get(username_data)["password"]:
                            pickle_out = open("loginuser.pickle", "wb")
                            pickledata = {'username': username_data}
                            pickle.dump(pickledata, pickle_out)
                            pickle_out.close()
                            
                            controller.show_frame(Page2)
                        else:
                            messagebox.showinfo("Alert!", "Please check your password")
                    else:
                        messagebox.showinfo("Alert!", "Account with this username doesn't exist!")
                except:
                    messagebox.showinfo("Alert!", "Account with this username doesn't exist!")

        button2 = tk.Button(frame, text="SUBMIT", width=10, height=1, bg = "firebrick", foreground = "white",
                            command=callback)
        button2.pack(pady=20, padx=10)



                
class Page1(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        frame = tk.Frame(self,bg="white")
        frame.pack(fill="both",expand=True)

        button = tk.Button(frame, text="BACK", width=10, height=1, bg = "firebrick", foreground = "white",
                            command=lambda: controller.show_frame(RegistrationPage))
        button.grid(row=0, column=0, padx=10, pady=20)

        label = tk.Label(frame, bg="white", text="Upload your image here to create the graphical password", font=("Arial", 15))
        label.grid(row=2, column=2)

        ##
        inputimagecanva = tk.Canvas(frame, width=300, height=300)
        inputimagecanva.grid(row=3, column=1, pady=70)
        
        logo = Image.open('inputimage.jpg').resize((300, 300))

        logo = ImageTk.PhotoImage(logo)
        inputimagecanva.background = logo
        inputimagecanva.create_image(0, 0, anchor="nw", image=logo)

        ##

        
        
        gridimagecanva = tk.Canvas(frame, width=300, height=300)
        gridimagecanva.grid(row=3, column=3, pady=60)

        gridimg = Image.open('grid.png').resize((300, 300))

        grid = ImageTk.PhotoImage(gridimg)
        gridimagecanva.background = grid
        gridimagecanva.create_image(0, 0, anchor="nw", image=grid)
        

        def uploadimage():
            global my_image
            global filename
            filename = filedialog.askopenfilename(initialdir="/", title="Select A File", filetypes=(("all images", "*.*"),("all files", "*.*")))
            
            my_image = ImageTk.PhotoImage(Image.open(filename).resize((300, 300)))
            inputimagecanva.background = my_image
            inputimagecanva.create_image(0, 0, anchor="nw", image=my_image)

        uploadbutton = tk.Button(frame, text="UPLOAD", width=10, height=1, bg = "firebrick", foreground = "white", command=uploadimage)
        uploadbutton.grid(row=4, column=2)

        def splitimage(filename):
            def split_image_into_grid(filename, grid_size=(3, 3)):
                original_image = Image.open(filename).resize((300, 300))
                cell_width = original_image.width // grid_size[0]
                cell_height = original_image.height // grid_size[1]
                
                grid_cells = []
                for row in range(grid_size[1]):
                    for col in range(grid_size[0]):
                        x0 = col * cell_width
                        y0 = row * cell_height
                        x1 = x0 + cell_width
                        y1 = y0 + cell_height
                        grid_cells.append(original_image.crop((x0, y0, x1, y1)))
                
                return original_image, grid_cells

            def draw_grid_lines(image, grid_size=(3, 3)):
                draw = ImageDraw.Draw(image)
                width, height = image.size
                cell_width = width // grid_size[0]
                cell_height = height // grid_size[1]
                
                # Draw vertical lines
                for i in range(1, grid_size[0]):
                    x = i * cell_width
                    draw.line((x, 0, x, height), fill="black", width=2)
                
                # Draw horizontal lines
                for i in range(1, grid_size[1]):
                    y = i * cell_height
                    draw.line((0, y, width, y), fill="black", width=2)

                pickle_in = open("usersdata.pickle", "rb")
                pickledata = pickle.load(pickle_in)
                current_user_dict = pickledata.get('current_user_dict')
                                    
                image_bytes = image.tobytes()
                current_user_dict.get("currentuser")["gridimage"] = image_bytes

                pickle_out = open("usersdata.pickle", "wb")
                pickledata = {'current_user_dict': current_user_dict}
                pickle.dump(pickledata, pickle_out)
                pickle_out.close()

                pickle_in = open("usersdata.pickle", "rb")
                pickledata = pickle.load(pickle_in)
                current_user_dict = pickledata.get('current_user_dict')

                reloaded_image_bytes = current_user_dict.get("currentuser")["gridimage"]

                reloaded_image = Image.frombytes('RGB', (300, 300), reloaded_image_bytes)

                grid = ImageTk.PhotoImage(reloaded_image)
                gridimagecanva.background = grid
                gridimagecanva.create_image(0, 0, anchor="nw", image=grid)

                
                
                return image

            def save_grid_images(grid_cells):
                for i, cell_image in enumerate(grid_cells):

                    pickle_in = open("usersdata.pickle", "rb")
                    pickledata = pickle.load(pickle_in)
                    current_user_dict = pickledata.get('current_user_dict')
                    
                    image_bytes = cell_image.tobytes()
                    current_user_dict.get("currentuser")[""+str(i)] = image_bytes

                    pickle_out = open("usersdata.pickle", "wb")
                    pickledata = {'current_user_dict': current_user_dict}
                    pickle.dump(pickledata, pickle_out)
                    pickle_out.close()
                                          

            original_image, grid_cells = split_image_into_grid(filename) 
            image_with_grid = draw_grid_lines(original_image)
            save_grid_images(grid_cells)

        all_users = {}
        
        try:
            pickle_in_allusers = open("allusers.pickle", "rb")
            pickledata_allusers = pickle.load(pickle_in_allusers)
            all_users = pickledata.get('all_users')
        except:
            pass

        
        
        def submitdata():
            pickle_in = open("usersdata.pickle", "rb")
            pickledata = pickle.load(pickle_in)
            current_user_dict = pickledata.get('current_user_dict')

            pickle_out = open("allusers.pickle", "wb")
            all_users[str(current_user_dict.get("currentuser")["username"])] = current_user_dict.get("currentuser")
            pickledata = {'all_users' : all_users}
            pickle.dump(pickledata, pickle_out)
            pickle_out.close()

            def resetGrid():
                
                logo = Image.open('inputimage.jpg').resize((300, 300))

                logo = ImageTk.PhotoImage(logo)
                inputimagecanva.background = logo
                inputimagecanva.create_image(0, 0, anchor="nw", image=logo)

                ##

                logo = Image.open('grid.png').resize((300, 300))
                
                grid = ImageTk.PhotoImage(logo)
                gridimagecanva.background = grid
                gridimagecanva.create_image(0, 0, anchor="nw", image=grid)

            
            messagebox.showinfo("Alert!", "Registration Successful")
            resetGrid()
            controller.show_frame(LoginPage)

        splitbutton = tk.Button(frame, text="SPLIT", width=10, height=1, bg = "firebrick", foreground = "white", command = lambda: splitimage(filename))
        splitbutton.grid(row=5, column=2, pady=10)

        submitbutton = tk.Button(frame, text="SUBMIT", width=10, height=1, bg = "firebrick", foreground = "white", command=submitdata)
        submitbutton.grid(row=6, column=2)

class Page2(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        frame = tk.Frame(self)
        frame.pack(fill="both",expand=True)

        frame2 = tk.Frame(self)
        frame2.pack(fill="both",expand=True, padx=500)

        def resetGrid():
            all_users={}
            pickle_in = open("loginuser.pickle", "rb")
            pickledata = pickle.load(pickle_in)
            username = pickledata.get("username")

##            print("username"+str(username))

            pickle_in = open("allusers.pickle", "rb")
            pickledata = pickle.load(pickle_in)
            current_user_dict = pickledata.get('all_users')

            numbers = list(range(9))
            random.shuffle(numbers)
            
            k=0
            
            for i in range(3):
                for j in range(3):
                    image_data = current_user_dict.get(username)[str(numbers[k])]
                    image = Image.frombytes('RGB', (100, 100), image_data)
                    photo = ImageTk.PhotoImage(image)
                    label = tk.Label(frame2, image=photo)
                    label.grid(row=i+4, column=j+2, padx=5, pady=5)
                    k = k+1


        def back():
            resetGrid()
            controller.show_frame(StartPage)

        button = tk.Button(frame, text="BACK", width=10, height=1, bg = "firebrick", foreground = "white",
                            command=back)
        button.grid(row=0, column=0, pady=20, padx=10)

        label = tk.Label(frame, text="Enter Your Grid Image Sequence", font=("Arial", 15))
        label.grid(row=1, column=1, pady=20, padx=(400, 10))

        imagesequence = tk.Entry(frame, bd=2)
        imagesequence.grid(row=2, column=1, pady=20, padx=(400, 10))


        def showgrid():
            all_users={}
            pickle_in = open("loginuser.pickle", "rb")
            pickledata = pickle.load(pickle_in)
            username = pickledata.get("username")

##            print("username"+str(username))

            pickle_in = open("allusers.pickle", "rb")
            pickledata = pickle.load(pickle_in)
            current_user_dict = pickledata.get('all_users')

            numbers = list(range(9))
            random.shuffle(numbers)
            
            k=0
            
            for i in range(3):
                for j in range(3):
                    image_data = current_user_dict.get(username)[str(numbers[k])]
                    image = Image.frombytes('RGB', (100, 100), image_data)
                    photo = ImageTk.PhotoImage(image)
                    label = tk.Label(frame2, image=photo)
                    label.grid(row=i+4, column=j+2, padx=5, pady=5)
                    label.image = photo
                    k = k+1

                
    

        def callback():
            username_data_sequence = imagesequence.get()
            if len(username_data_sequence) ==0:
                messagebox.showinfo("Alert!", "Please enter image sequence")
            elif len(username_data_sequence)<9 or len(username_data_sequence)>9:
                messagebox.showinfo("Alert!", "Image sequence length should be 9")
            elif username_data_sequence.isdigit() == False:
                messagebox.showinfo("Alert!", "Please enter only digits")
            else:
                num_string = ''.join(str(num) for num in numbers)
                if username_data_sequence == num_string:
                    controller.show_frame(HomePage)
                else:
                    messagebox.showinfo("Alert!", "Please select correct sequence")
            
        showgridbutton = tk.Button(frame, text="Show & Reload Grid", width=20, height=1, bg = "firebrick", foreground = "white", command=showgrid)
        showgridbutton.grid(row=3, column=1, pady=20, padx=(400, 10))
        
        submitbutton = tk.Button(frame, text="SUBMIT", width=10, height=1, bg = "firebrick", foreground = "white", command=callback)
        submitbutton.grid(row=4, column=1, pady=20, padx=(400, 10))


class HomePage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        frame = tk.Frame(self,bg="white")
        frame.pack(fill="both",expand=True)

        IMAGE_PATH = 'back.jpg'

        img = ImageTk.PhotoImage(Image.open(IMAGE_PATH).resize((1600, 800)))
        lbl = tk.Label(frame, image=img)
        lbl.img = img
        lbl.place(relx=0.5, rely=0.5, anchor='center')
        
        label = tk.Label(frame, bg="white", text="Welcome to Dashboard", font=("Arial", 50))
        label.pack(pady=100,padx=10)

        

app = GraphicalPasswordApp()
app.title('Graphical Password Authentication System')
app.geometry('1600x800+0+0')
app.mainloop()
